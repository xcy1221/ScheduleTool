<script setup lang="ts">
import '@homeserver/theme/tokens.css';

defineProps<{ name: string; home?: boolean }>();
defineEmits<{ appearance: [] }>();
</script>
<template>
  <header class="site-header" aria-label="Server Panel 顶部栏">
    <span class="site-name">
      <span class="site-brand">HOMESERVER</span>
      <span class="site-title" :title="name">{{ name }}</span>
    </span>
    <a v-if="!home" class="back-link" href="/server-readme/" target="_top">←返回server panel</a>
    <button id="appearance-trigger" type="button" aria-haspopup="dialog" aria-controls="appearance-dialog" aria-expanded="false" @click="$emit('appearance')">外观与排版</button>
  </header>
</template>

<style scoped>
.site-header {
  position: sticky;
  z-index: 45;
  top: 0;
  display: flex;
  align-items: center;
  gap: 16px;
  box-sizing: border-box;
  min-height: var(--server-header-height);
  padding: 0 clamp(12px, 2%, 32px);
  border-bottom: 1px solid var(--hs-line);
  background: var(--hs-surface);
  color: var(--hs-text);
  color-scheme: var(--hs-color-scheme);
  font: 13px/1.35 var(--hs-font);
}
.site-name { display: flex; flex: 1; align-items: baseline; gap: 10px; min-width: 0; }
.site-brand { color: var(--hs-muted); font-size: 11px; font-weight: 750; letter-spacing: .09em; }
.site-title {
  overflow: hidden;
  padding-inline-start: 10px;
  border-inline-start: 1px solid var(--hs-line);
  color: var(--hs-text);
  font-size: 14px;
  font-weight: 700;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.back-link, #appearance-trigger {
  display: inline-flex;
  flex: 0 0 auto;
  align-items: center;
  min-height: 40px;
  white-space: nowrap;
}
.back-link { color: var(--hs-muted); font-weight: 550; text-decoration: none; }
.back-link:hover { color: var(--hs-accent); text-decoration: underline; text-underline-offset: 3px; }
#appearance-trigger {
  justify-content: center;
  padding: 0 12px;
  border: 1px solid var(--hs-line);
  border-radius: var(--hs-radius);
  background: var(--hs-surface);
  color: var(--hs-text);
  font: 600 12px/1.35 var(--hs-font);
  cursor: pointer;
}
#appearance-trigger:hover, #appearance-trigger[aria-expanded="true"] {
  border-color: var(--hs-accent);
  background: var(--hs-hover);
}
:is(.back-link, #appearance-trigger):focus-visible {
  outline: 2px solid var(--hs-accent);
  outline-offset: 3px;
}
@media (max-width: 600px) {
  .site-header { gap: 10px; font-size: 11px; }
  .site-name { display: grid; gap: 2px; }
  .site-brand { font-size: 9px; letter-spacing: .06em; }
  .site-title { padding: 0; border: 0; font-size: 12px; }
  #appearance-trigger { padding-inline: 8px; font-size: 11px; }
}
</style>
