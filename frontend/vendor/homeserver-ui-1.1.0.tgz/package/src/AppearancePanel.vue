<script setup lang="ts">
import { ref } from 'vue';
import { tones, toneNames, useTheme } from '@homeserver/theme';
import type { PageOptions } from '@homeserver/theme';
import '@homeserver/theme/tokens.css';
import LayoutControls from './LayoutControls.vue';

const props = defineProps<{ page: PageOptions; legacyThemeKey?: string }>();
const emit = defineEmits<{ reset: [] }>();
const dialog = ref<HTMLDialogElement>();
const layout = ref<InstanceType<typeof LayoutControls>>();
const message = ref('');
const { state, select } = useTheme(props.legacyThemeKey);
const themeModes = [
  { id: 'light', label: '浅色' },
  { id: 'dark', label: '深色' },
] as const;
let trigger: HTMLElement | null = null;

function open() {
  const element = dialog.value;
  if (!element || element.open) return;
  trigger = document.getElementById('appearance-trigger');
  message.value = '';
  element.showModal();
  trigger?.setAttribute('aria-expanded', 'true');
  element.querySelector<HTMLInputElement>('input[name="theme"]:checked')?.focus();
}

function close() {
  dialog.value?.close();
}

function onClosed() {
  trigger?.setAttribute('aria-expanded', 'false');
  trigger?.focus();
  trigger = null;
}

function onBackdrop(event: MouseEvent) {
  const element = dialog.value;
  if (!element || event.target !== element) return;
  const { left, right, top, bottom } = element.getBoundingClientRect();
  if (event.clientX < left || event.clientX > right || event.clientY < top || event.clientY > bottom) close();
}

function reset() {
  layout.value?.reset();
  emit('reset');
  message.value = '已恢复本页默认排版。';
}

defineExpose({ open, close, reset });
</script>

<template>
  <dialog ref="dialog" id="appearance-dialog" aria-labelledby="appearance-title" @close="onClosed" @click="onBackdrop" @keydown.esc.stop>
    <header class="appearance-heading">
      <h2 id="appearance-title">外观与排版</h2>
      <button id="appearance-close" type="button" aria-label="关闭外观与排版" @click="close">×</button>
    </header>
    <p class="appearance-note">明暗与色调在面板各页同步，排版设置仅应用于当前页。</p>
    <form id="appearance-form" @submit.prevent>
      <fieldset>
        <legend>界面明暗</legend>
        <div class="appearance-choices">
          <label v-for="mode in themeModes" :key="mode.id">
            <input type="radio" name="theme" :value="mode.id" :checked="state.theme === mode.id" @change="select('theme', mode.id)">
            {{ mode.label }}
          </label>
        </div>
      </fieldset>
      <fieldset>
        <legend>界面色调</legend>
        <div class="appearance-choices">
          <label v-for="(tone, index) in tones" :key="tone">
            <input type="radio" name="tone" :value="tone" :checked="state.tone === tone" @change="select('tone', tone)">
            <span class="swatch" :class="tone" aria-hidden="true"></span>
            {{ toneNames[index] }}
          </label>
        </div>
      </fieldset>
      <LayoutControls ref="layout" :page="page" />
      <slot></slot>
      <button id="appearance-reset" type="button" @click="reset">恢复本页默认排版</button>
      <p id="appearance-status" role="status" aria-live="polite">{{ state.storageFailed ? '浏览器未允许保存设置，本次调整仍然生效。' : message }}</p>
    </form>
  </dialog>
</template>

<style scoped>
#appearance-dialog {
  position: fixed;
  inset: 0 0 0 auto;
  box-sizing: border-box;
  width: min(420px, 100%);
  height: 100%;
  max-width: 100%;
  max-height: 100dvh;
  margin: 0;
  padding: clamp(16px, 4vw, 24px);
  overflow: auto;
  overscroll-behavior: contain;
  border: 0;
  border-left: 1px solid var(--hs-line);
  background: var(--hs-surface);
  color: var(--hs-text);
  color-scheme: var(--hs-color-scheme);
  box-shadow: -12px 0 40px var(--hs-shadow);
  font: 13px/1.65 var(--hs-font);
}
#appearance-dialog::backdrop { background: var(--hs-backdrop); }
:global(html:has(#appearance-dialog[open])) { overflow: hidden; }
.appearance-heading { display: flex; align-items: center; justify-content: space-between; gap: 16px; }
.appearance-heading h2 { margin: 0; color: inherit; font: 700 20px/1.35 var(--hs-font); }
.appearance-note, #appearance-status { margin: 12px 0; color: var(--hs-muted); font-size: 12px; }
#appearance-status:empty { display: none; }
#appearance-form { margin: 0; }
#appearance-form fieldset {
  min-width: 0;
  margin: 16px 0 0;
  padding: 0 0 16px;
  border: 0;
  border-bottom: 1px solid var(--hs-line);
}
#appearance-form legend { margin-bottom: 8px; padding: 0; font-weight: 650; }
.appearance-choices { display: flex; flex-wrap: wrap; gap: 8px; }
.appearance-choices > label {
  display: flex;
  align-items: center;
  gap: 6px;
  min-height: 36px;
  padding: 2px 8px;
  border: 1px solid var(--hs-line);
  border-radius: var(--hs-radius);
  cursor: pointer;
}
.appearance-choices > label:has(:checked) { background: var(--hs-active); border-color: var(--hs-accent); }
.appearance-choices input {
  flex: 0 0 auto;
  width: 13px;
  height: 13px;
  margin: 0;
  padding: 0;
  accent-color: var(--hs-accent);
}
.swatch { width: 11px; height: 11px; border-radius: 50%; }
.swatch.green { background: #8db8a1; }
.swatch.blue { background: #90b2d1; }
.swatch.red { background: #d69b91; }
.swatch.pink { background: #d7a0ba; }
.swatch.purple { background: #b5a1cf; }
#appearance-close, #appearance-reset {
  min-height: 36px;
  padding: 6px 12px;
  border: 1px solid var(--hs-line);
  border-radius: var(--hs-radius);
  background: var(--hs-surface);
  color: var(--hs-text);
  font: inherit;
  cursor: pointer;
}
#appearance-close { width: 36px; padding: 0; font-size: 22px; line-height: 1; }
#appearance-reset { margin-top: 8px; }
:is(#appearance-close, #appearance-reset):hover { background: var(--hs-hover); }
:is(#appearance-close, #appearance-reset, .appearance-choices input):focus-visible {
  outline: 2px solid var(--hs-accent);
  outline-offset: 2px;
}
</style>
