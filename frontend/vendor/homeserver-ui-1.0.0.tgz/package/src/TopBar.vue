<script setup lang="ts">
defineProps<{ name: string; home?: boolean }>();
defineEmits<{ appearance: [] }>();
</script>
<template>
  <header class="site-header">
    <span class="site-name">HOMESERVER <span>· {{ name }}</span></span>
    <a v-if="!home" class="back-link" href="/server-readme/" target="_top">←返回server panel</a>
    <button id="appearance-trigger" type="button" aria-haspopup="dialog" aria-controls="appearance-dialog" @click="$emit('appearance')">外观与排版</button>
  </header>
</template>
