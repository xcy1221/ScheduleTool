<script setup lang="ts">
import { onMounted, onUnmounted, ref } from 'vue';
import { create } from '@homeserver/theme/layout';
import type { PageOptions } from '@homeserver/theme';
const props = defineProps<{ page: PageOptions }>();
const host = ref<HTMLElement>(); let layout: any;
onMounted(() => { layout = create(props.page); layout.mount(host.value!); });
onUnmounted(() => layout?.destroy());
defineExpose({ reset: () => layout?.reset() });
</script>
<template><div ref="host"></div></template>
