<script setup lang="ts">
import { ref } from 'vue';
import TopBar from './TopBar.vue';
import AppearancePanel from './AppearancePanel.vue';
import type { PageOptions } from '@homeserver/theme';
defineProps<{ name: string; page: PageOptions }>();
const appearance = ref<InstanceType<typeof AppearancePanel>>();
</script>
<template><TopBar :name="name" @appearance="appearance?.open()" /><main><slot></slot></main><AppearancePanel ref="appearance" :page="page" /></template>
