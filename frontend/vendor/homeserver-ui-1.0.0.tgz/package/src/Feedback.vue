<script setup lang="ts">defineProps<{ loading?: boolean; error?: string }>();</script>
<template><p v-if="loading || error" role="status" :data-kind="error ? 'error' : 'info'">{{ error || '正在加载…' }}</p><slot v-else></slot></template>
