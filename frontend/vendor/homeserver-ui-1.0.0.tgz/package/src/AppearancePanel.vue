<script setup lang="ts">
import { ref, onMounted } from 'vue';
import { tones, toneNames, useTheme } from '@homeserver/theme';
import type { PageOptions } from '@homeserver/theme';
import LayoutControls from './LayoutControls.vue';
const props = defineProps<{ page: PageOptions; legacyThemeKey?: string }>();
const emit = defineEmits<{ reset: [] }>();
const dialog = ref<HTMLDialogElement>(); const layout = ref<InstanceType<typeof LayoutControls>>();
const { state, select } = useTheme(props.legacyThemeKey);
const message = ref('');
function close() { dialog.value?.close(); document.getElementById('appearance-trigger')?.setAttribute('aria-expanded', 'false'); document.getElementById('appearance-trigger')?.focus(); }
function open() { dialog.value?.showModal(); document.getElementById('appearance-trigger')?.setAttribute('aria-expanded', 'true'); }
function reset() { layout.value?.reset(); emit('reset'); message.value = '已恢复默认排版。'; }
onMounted(() => dialog.value?.addEventListener('close', () => document.getElementById('appearance-trigger')?.setAttribute('aria-expanded', 'false')));
defineExpose({ open, close, reset });
</script>
<template>
  <dialog ref="dialog" id="appearance-dialog" aria-labelledby="appearance-title">
    <div class="appearance-heading"><h2 id="appearance-title">外观与排版</h2><button id="appearance-close" type="button" aria-label="关闭外观设置" @click="close">×</button></div>
    <p id="appearance-note">即时生效，自动保存在当前浏览器。明暗与色调和日程工具同步。</p>
    <form id="appearance-form" @submit.prevent>
      <fieldset><legend>界面明暗</legend><div class="appearance-modes"><label v-for="(name, index) in ['浅色','深色']" :key="name"><input type="radio" name="theme" :value="index ? 'dark' : 'light'" :checked="state.theme === (index ? 'dark' : 'light')" @change="select('theme', index ? 'dark' : 'light')">{{ name }}</label></div></fieldset>
      <fieldset><legend>界面色调</legend><div class="appearance-tones"><label v-for="(tone, index) in tones" :key="tone"><input type="radio" name="tone" :value="tone" :checked="state.tone === tone" @change="select('tone', tone)"><i class="swatch" :class="tone"></i>{{ toneNames[index] }}</label></div></fieldset>
      <LayoutControls ref="layout" :page="page" />
      <slot></slot><button id="appearance-reset" type="button" @click="reset">恢复默认排版</button>
      <p id="appearance-status" class="appearance-hint" role="status" aria-live="polite">{{ state.storageFailed ? '浏览器未允许保存设置；本次调整仍然生效。' : message }}</p>
    </form>
  </dialog>
</template>
