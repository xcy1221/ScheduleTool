import { reactive, onMounted, onUnmounted, watch } from 'vue';

export const tones = ['green', 'blue', 'red', 'pink', 'purple'] as const;
export const toneNames = ['淡绿色', '淡蓝色', '淡红色', '淡粉色', '淡紫色'];
export const keys = { theme: 'scheduletool-theme', tone: 'scheduletool-tone', layout: 'serverpanel-page-layout-v1:' };
export interface PageOptions { id: string; legacyKey?: string; columns?: number; rows?: boolean; defaultColumns?: number | 'auto' | 'default'; gap?: number; cardGap?: boolean }
export function read(key: string, fallback: string | null = null) { try { return localStorage.getItem(key) ?? fallback; } catch { return fallback; } }
export function write(key: string, value: string) { try { localStorage.setItem(key, value); return true; } catch { return false; } }
export function useTheme(legacyKey?: string) {
  function saved() {
    let old: any = {}; try { old = JSON.parse(read(legacyKey || '', '{}') || '{}'); } catch {}
    return { theme: read(keys.theme, old.theme) === 'light' ? 'light' : 'dark', tone: tones.includes(read(keys.tone, old.tone) as any) ? read(keys.tone, old.tone)! : 'green' };
  }
  const state = reactive({ ...saved(), storageFailed: false });
  function apply() {
    const root = document.documentElement; root.dataset.theme = state.theme; root.dataset.tone = state.tone;
    document.querySelector('meta[name=color-scheme]')?.setAttribute('content', state.theme);
    document.querySelector('meta[name=theme-color]')?.setAttribute('content', getComputedStyle(root).getPropertyValue('--bg').trim() || getComputedStyle(root).backgroundColor);
  }
  function select(field: 'theme' | 'tone', value: string) {
    if (field === 'theme' ? !['light', 'dark'].includes(value) : !tones.includes(value as any)) return;
    state[field] = value; state.storageFailed = !write(keys[field], value) || state.storageFailed;
    if (legacyKey) write(legacyKey, JSON.stringify({ theme: state.theme, tone: state.tone }));
    apply();
  }
  function storage(event: StorageEvent) { if (event.key === null || [keys.theme, keys.tone, legacyKey].includes(event.key)) { Object.assign(state, saved()); apply(); } }
  onMounted(() => { apply(); window.addEventListener('storage', storage); });
  onUnmounted(() => window.removeEventListener('storage', storage));
  watch(() => [state.theme, state.tone], apply);
  return { state, select, apply };
}
