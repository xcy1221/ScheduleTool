import type { PageOptions } from './index';
export interface LayoutController { mount(host: HTMLElement): void; reset(): void; destroy(): void }
export function create(options: PageOptions): LayoutController;
export function normalize(value: unknown, options: PageOptions): Record<string, any>;
